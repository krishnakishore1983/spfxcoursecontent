/* tslint:disable */
require("./ExtLibDemoWebPart.module.css");
const styles = {
  extLibDemo: 'extLibDemo_58abc165',
  container: 'container_58abc165',
  row: 'row_58abc165',
  column: 'column_58abc165',
  'ms-Grid': 'ms-Grid_58abc165',
  title: 'title_58abc165',
  subTitle: 'subTitle_58abc165',
  description: 'description_58abc165',
  button: 'button_58abc165',
  label: 'label_58abc165'
};

export default styles;
/* tslint:enable */