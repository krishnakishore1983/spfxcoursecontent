define([], function() {
  return {
    "Title": "FecDemoFieldCustomizer"
  }
});