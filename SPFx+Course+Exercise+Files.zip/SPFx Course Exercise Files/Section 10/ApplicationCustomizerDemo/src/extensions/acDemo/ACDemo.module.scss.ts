/* tslint:disable */
require("./ACDemo.module.css");
const styles = {
  acdemoapp: 'acdemoapp_2088400f',
  topPlaceholder: 'topPlaceholder_2088400f',
  bottomPlaceholder: 'bottomPlaceholder_2088400f'
};

export default styles;
/* tslint:enable */