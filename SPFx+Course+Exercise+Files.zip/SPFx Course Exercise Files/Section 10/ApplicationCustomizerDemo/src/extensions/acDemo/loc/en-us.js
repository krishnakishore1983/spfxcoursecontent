define([], function() {
  return {
    "Title": "AcDemoApplicationCustomizer"
  }
});