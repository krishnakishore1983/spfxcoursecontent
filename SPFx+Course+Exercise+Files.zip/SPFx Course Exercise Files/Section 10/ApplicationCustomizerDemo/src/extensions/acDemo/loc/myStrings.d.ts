declare interface IAcDemoApplicationCustomizerStrings {
  Title: string;
}

declare module 'AcDemoApplicationCustomizerStrings' {
  const strings: IAcDemoApplicationCustomizerStrings;
  export = strings;
}
