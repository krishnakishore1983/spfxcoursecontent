/* tslint:disable */
require("./MyFieldCustomizerExtensionFieldCustomizer.module.css");
const styles = {
  MyFieldCustomizerExtension: 'MyFieldCustomizerExtension_044fc8b7',
  cell: 'cell_044fc8b7'
};

export default styles;
/* tslint:enable */