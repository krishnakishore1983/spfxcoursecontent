/* tslint:disable */
require("./MyIsolatedWebPartWebPart.module.css");
const styles = {
  myIsolatedWebPart: 'myIsolatedWebPart_4f7ad174',
  container: 'container_4f7ad174',
  row: 'row_4f7ad174',
  column: 'column_4f7ad174',
  'ms-Grid': 'ms-Grid_4f7ad174',
  title: 'title_4f7ad174',
  subTitle: 'subTitle_4f7ad174',
  description: 'description_4f7ad174',
  button: 'button_4f7ad174',
  label: 'label_4f7ad174'
};

export default styles;
/* tslint:enable */