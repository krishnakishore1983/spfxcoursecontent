/* tslint:disable */
require("./AnonymousApiwpDemo.module.css");
const styles = {
  anonymousApiwpDemo: 'anonymousApiwpDemo_c7597f15',
  container: 'container_c7597f15',
  row: 'row_c7597f15',
  column: 'column_c7597f15',
  'ms-Grid': 'ms-Grid_c7597f15',
  title: 'title_c7597f15',
  subTitle: 'subTitle_c7597f15',
  description: 'description_c7597f15',
  button: 'button_c7597f15',
  label: 'label_c7597f15'
};

export default styles;
/* tslint:enable */