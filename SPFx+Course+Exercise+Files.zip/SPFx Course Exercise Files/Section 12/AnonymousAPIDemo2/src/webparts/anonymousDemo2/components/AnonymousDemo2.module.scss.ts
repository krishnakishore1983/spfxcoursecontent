/* tslint:disable */
require("./AnonymousDemo2.module.css");
const styles = {
  anonymousDemo2: 'anonymousDemo2_662c488d',
  container: 'container_662c488d',
  row: 'row_662c488d',
  column: 'column_662c488d',
  'ms-Grid': 'ms-Grid_662c488d',
  title: 'title_662c488d',
  subTitle: 'subTitle_662c488d',
  description: 'description_662c488d',
  button: 'button_662c488d',
  label: 'label_662c488d'
};

export default styles;
/* tslint:enable */