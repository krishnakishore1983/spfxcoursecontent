export interface ISPList{
    Title:string;
    Id:string;
    ImageUrl:string;
}