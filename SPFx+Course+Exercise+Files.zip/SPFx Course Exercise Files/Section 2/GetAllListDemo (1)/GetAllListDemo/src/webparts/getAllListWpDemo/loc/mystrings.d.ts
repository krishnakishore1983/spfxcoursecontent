declare interface IGetAllListWpDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'GetAllListWpDemoWebPartStrings' {
  const strings: IGetAllListWpDemoWebPartStrings;
  export = strings;
}
