/* tslint:disable */
require("./CultureInfoDetailsWebPart.module.css");
const styles = {
  cultureInfoDetails: 'cultureInfoDetails_b66b3c49',
  container: 'container_b66b3c49',
  row: 'row_b66b3c49',
  column: 'column_b66b3c49',
  'ms-Grid': 'ms-Grid_b66b3c49',
  title: 'title_b66b3c49',
  subTitle: 'subTitle_b66b3c49',
  description: 'description_b66b3c49',
  button: 'button_b66b3c49',
  label: 'label_b66b3c49'
};

export default styles;
/* tslint:enable */