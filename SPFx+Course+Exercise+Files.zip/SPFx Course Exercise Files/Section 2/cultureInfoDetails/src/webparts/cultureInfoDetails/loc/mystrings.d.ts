declare interface ICultureInfoDetailsWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CultureInfoDetailsWebPartStrings' {
  const strings: ICultureInfoDetailsWebPartStrings;
  export = strings;
}
