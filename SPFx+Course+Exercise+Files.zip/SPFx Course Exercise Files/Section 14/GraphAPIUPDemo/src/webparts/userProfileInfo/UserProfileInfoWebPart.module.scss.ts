/* tslint:disable */
require("./UserProfileInfoWebPart.module.css");
const styles = {
  userProfileInfo: 'userProfileInfo_5f2da885',
  container: 'container_5f2da885',
  row: 'row_5f2da885',
  column: 'column_5f2da885',
  'ms-Grid': 'ms-Grid_5f2da885',
  title: 'title_5f2da885',
  subTitle: 'subTitle_5f2da885',
  description: 'description_5f2da885',
  button: 'button_5f2da885',
  label: 'label_5f2da885'
};

export default styles;
/* tslint:enable */