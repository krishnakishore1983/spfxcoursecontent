/* tslint:disable */
require("./ShowAllUsers.module.css");
const styles = {
  showAllUsers: 'showAllUsers_1e9e47e3',
  container: 'container_1e9e47e3',
  row: 'row_1e9e47e3',
  column: 'column_1e9e47e3',
  'ms-Grid': 'ms-Grid_1e9e47e3',
  title: 'title_1e9e47e3',
  subTitle: 'subTitle_1e9e47e3',
  description: 'description_1e9e47e3',
  button: 'button_1e9e47e3',
  label: 'label_1e9e47e3'
};

export default styles;
/* tslint:enable */