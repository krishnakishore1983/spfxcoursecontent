declare interface ICalendarEventsDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'CalendarEventsDemoWebPartStrings' {
  const strings: ICalendarEventsDemoWebPartStrings;
  export = strings;
}
