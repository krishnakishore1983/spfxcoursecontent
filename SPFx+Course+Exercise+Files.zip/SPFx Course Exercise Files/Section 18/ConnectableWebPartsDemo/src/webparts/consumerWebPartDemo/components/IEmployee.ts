
export interface IEmployee {
    Id: number;
    Title: string;    
    DeptTitle: string;
    Designation: string;

}
