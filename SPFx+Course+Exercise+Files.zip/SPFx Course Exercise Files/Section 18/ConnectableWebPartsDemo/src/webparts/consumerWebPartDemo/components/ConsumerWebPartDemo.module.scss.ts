/* tslint:disable */
require("./ConsumerWebPartDemo.module.css");
const styles = {
  consumerWebPartDemo: 'consumerWebPartDemo_6bab3a8e',
  container: 'container_6bab3a8e',
  row: 'row_6bab3a8e',
  column: 'column_6bab3a8e',
  'ms-Grid': 'ms-Grid_6bab3a8e',
  title: 'title_6bab3a8e',
  subTitle: 'subTitle_6bab3a8e',
  description: 'description_6bab3a8e',
  button: 'button_6bab3a8e',
  label: 'label_6bab3a8e'
};

export default styles;
/* tslint:enable */