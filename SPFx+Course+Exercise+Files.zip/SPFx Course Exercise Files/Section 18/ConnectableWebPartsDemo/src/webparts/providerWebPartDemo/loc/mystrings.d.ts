declare interface IProviderWebPartDemoWebPartStrings {
  PropertyPaneDescription: string;
  BasicGroupName: string;
  DescriptionFieldLabel: string;
}

declare module 'ProviderWebPartDemoWebPartStrings' {
  const strings: IProviderWebPartDemoWebPartStrings;
  export = strings;
}
