/* tslint:disable */
require("./ProviderWebPartDemo.module.css");
const styles = {
  providerWebPartDemo: 'providerWebPartDemo_817f46db',
  container: 'container_817f46db',
  row: 'row_817f46db',
  column: 'column_817f46db',
  'ms-Grid': 'ms-Grid_817f46db',
  title: 'title_817f46db',
  subTitle: 'subTitle_817f46db',
  description: 'description_817f46db',
  button: 'button_817f46db',
  label: 'label_817f46db'
};

export default styles;
/* tslint:enable */