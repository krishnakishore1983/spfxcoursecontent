/* tslint:disable */
require("./CrudWithReact.module.css");
const styles = {
  crudWithReact: 'crudWithReact_f6785fe5',
  container: 'container_f6785fe5',
  row: 'row_f6785fe5',
  column: 'column_f6785fe5',
  'ms-Grid': 'ms-Grid_f6785fe5',
  title: 'title_f6785fe5',
  subTitle: 'subTitle_f6785fe5',
  description: 'description_f6785fe5',
  button: 'button_f6785fe5',
  label: 'label_f6785fe5'
};

export default styles;
/* tslint:enable */