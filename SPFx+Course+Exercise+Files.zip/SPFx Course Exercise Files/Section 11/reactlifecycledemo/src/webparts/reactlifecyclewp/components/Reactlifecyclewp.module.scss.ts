/* tslint:disable */
require("./Reactlifecyclewp.module.css");
const styles = {
  reactlifecyclewp: 'reactlifecyclewp_242c0364',
  container: 'container_242c0364',
  row: 'row_242c0364',
  column: 'column_242c0364',
  'ms-Grid': 'ms-Grid_242c0364',
  title: 'title_242c0364',
  subTitle: 'subTitle_242c0364',
  description: 'description_242c0364',
  button: 'button_242c0364',
  label: 'label_242c0364'
};

export default styles;
/* tslint:enable */