export interface IWebPartWithReactProps {
  description: string;
  absoluteurl: string;
  sitetitle: string;
  relativeurl: string;
  username: string;
}
