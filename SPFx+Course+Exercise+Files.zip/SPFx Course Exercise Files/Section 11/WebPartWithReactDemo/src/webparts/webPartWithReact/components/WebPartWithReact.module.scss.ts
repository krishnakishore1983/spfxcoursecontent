/* tslint:disable */
require("./WebPartWithReact.module.css");
const styles = {
  webPartWithReact: 'webPartWithReact_816c257a',
  container: 'container_816c257a',
  row: 'row_816c257a',
  column: 'column_816c257a',
  'ms-Grid': 'ms-Grid_816c257a',
  title: 'title_816c257a',
  subTitle: 'subTitle_816c257a',
  description: 'description_816c257a',
  button: 'button_816c257a',
  label: 'label_816c257a'
};

export default styles;
/* tslint:enable */